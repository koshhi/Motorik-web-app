my-web-app/
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── App.js
│   │   ├── index.js
│   ├── .env
│   ├── package.json
│   ├── .gitignore
│   └── README.md
├── backend/
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   ├── .env
│   ├── package.json
│   ├── .gitignore
│   ├── server.js
│   └── README.md
└── README.md
