const MyEventsSettings = () => {
  return (
    <>
      <h1>My Events Settings</h1>
    </>
  );
};

export default MyEventsSettings;