const MyEventsAttendees = () => {
  return (
    <>
      <h1>My EventsAttendees</h1>
    </>
  );
};

export default MyEventsAttendees;