import React from 'react';

const VerifyEmail = () => {
  return (
    <div>
      <h2>Check your email</h2>
      <p>We have sent a verification link to your email. Please verify your email before logging in.</p>
    </div>
  );
};

export default VerifyEmail;
