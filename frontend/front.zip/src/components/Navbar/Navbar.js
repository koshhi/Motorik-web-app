import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
// import styles from './Navbar.module.scss';
import { Topbar, ActionsContainer } from './NavbarStyles';
import Button from '../Button/Button';


const Navbar = () => {
  const navigate = useNavigate();

  // Verificar si el usuario está autenticado
  const isAuthenticated = !!localStorage.getItem('authToken');

  const handleLogout = () => {
    // Eliminar el token del almacenamiento local
    localStorage.removeItem('authToken');

    // Redirigir al login
    navigate('/login', { state: { message: 'You have been logged out successfully.' } });
  };

  const handleCreateEvent = () => {
    if (isAuthenticated) {
      navigate('/create-event'); // Redirigir a la página de creación de eventos si está autenticado
    } else {
      navigate('/login', { state: { message: 'You need to log in to create an event.' } }); // Redirigir al login si no está autenticado
    }
  };

  return (
    <Topbar>
      <div className='container'>
        <ActionsContainer to="/" >
          <img src='/motorik-logo.svg' alt="Motorik Logo" />
        </ActionsContainer>
        {isAuthenticated ? (
          <ActionsContainer>
            <Button size="small" variant="defaultInverse" onClick={handleCreateEvent}>Create event</Button>
            <Button size="small" variant="outlineInverse" onClick={handleLogout}>Logout</Button>
          </ActionsContainer>
        ) : (
          <>
            <ActionsContainer>
              <Button size="small" variant="defaultInverse" onClick={handleCreateEvent}>Create event</Button>
              <Link to="/login"><button className='button'>Login</button></Link>
              <Link to="/signup"><button className='button'>Signup</button></Link>
            </ActionsContainer>
          </>
        )}
      </div>
    </Topbar>
  );
};

export default Navbar;
