import styled from 'styled-components';

export const Topbar = styled.header`
  background-color: ${({ theme }) => theme.fill.inverseMain};
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;

  .container {
    
    display: flex;
    color: white;
    flex-direction: row;
    align-items: center;
    flex-grow: 1;
    justify-content: space-between;
    padding: ${({ theme }) => theme.sizing.sm} ${({ theme }) => theme.sizing.md};
    max-width: 1248px;
  }
`;

export const ActionsContainer = styled.div`
  display: flex;
  flex-direction: row;
  column-gap: 8px;
`;